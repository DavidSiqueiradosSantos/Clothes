export class Categoria {
  id: number;
  nome: string;
}
