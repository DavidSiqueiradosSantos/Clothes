export class Menu{
  categoriaId:number;
  descricao: string;
  rota: string;
}
