import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterStateSnapshot } from '@angular/router';
import { Produto } from '../models/produtos';

@Component({
  selector: 'app-lista-produto',
  templateUrl: './lista-produto.component.html',
  styleUrls: ['./lista-produto.component.css']
})
export class ListaProdutoComponent implements OnInit {
  produtos: Produto[] = [];
  categoria: string ='';
  tipocategoria: string ='';

  constructor(private http: HttpClient, private router: Router, private route: ActivatedRoute) {

    this.router.events.subscribe( value => {
      this.obterProdutos();
    })
  }

  ngOnInit() {
    this.obterProdutos();
  }

  obterProdutos(){

    this.obterParametros();

    this.http.get<Produto[]>('./assets/dados/produtos.json')
    .subscribe(produto=> {

      this.produtos = produto
      if(this.categoria){
        this.produtos = this.produtos.filter(x=>x.marca.trim().toLowerCase() == this.categoria.trim().toLowerCase());
      }
    });

  }

  obterParametros(){
    this.categoria = this.route.snapshot.params['categoria'];
    this.tipocategoria = this.route.snapshot.params['tipocategoria'];
  }
}
