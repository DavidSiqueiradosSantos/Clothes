export class Produto {

  id: number;
  nome: string;
  cor: string;
  estilo: string;
  marca: string;
  img: string;
  descricao:string;
}
